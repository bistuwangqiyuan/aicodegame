(()=>{var e={};e.id=267,e.ids=[267],e.modules={7849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},5403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},4749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},3685:e=>{"use strict";e.exports=require("http")},5687:e=>{"use strict";e.exports=require("https")},5477:e=>{"use strict";e.exports=require("punycode")},2781:e=>{"use strict";e.exports=require("stream")},7310:e=>{"use strict";e.exports=require("url")},9796:e=>{"use strict";e.exports=require("zlib")},8649:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>l.a,__next_app__:()=>p,originalPathname:()=>u,pages:()=>d,routeModule:()=>h,tree:()=>c});var s=r(482),a=r(9108),i=r(2563),l=r.n(i),o=r(8300),n={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(n[e]=()=>o[e]);r.d(t,n);let c=["",{children:["(dashboard)",{children:["teacher",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,1318)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\teacher\\page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(r.bind(r,5021)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\layout.tsx"],"not-found":[()=>Promise.resolve().then(r.t.bind(r,9361,23)),"next/dist/client/components/not-found-error"]}]},{layout:[()=>Promise.resolve().then(r.bind(r,3933)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\layout.tsx"],error:[()=>Promise.resolve().then(r.bind(r,4117)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\error.tsx"],"not-found":[()=>Promise.resolve().then(r.t.bind(r,9361,23)),"next/dist/client/components/not-found-error"]}],d=["C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\teacher\\page.tsx"],u="/(dashboard)/teacher/page",p={require:r,loadChunk:()=>Promise.resolve()},h=new s.AppPageRouteModule({definition:{kind:a.x.APP_PAGE,page:"/(dashboard)/teacher/page",pathname:"/teacher",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},6987:(e,t,r)=>{Promise.resolve().then(r.bind(r,1275))},5187:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(9224).Z)("Award",[["circle",{cx:"12",cy:"8",r:"6",key:"1vp47v"}],["path",{d:"M15.477 12.89 17 22l-5-3-5 3 1.523-9.11",key:"em7aur"}]])},3211:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(9224).Z)("BookOpen",[["path",{d:"M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z",key:"vv98re"}],["path",{d:"M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z",key:"1cyq3y"}]])},7189:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(9224).Z)("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]])},4826:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(9224).Z)("Code",[["polyline",{points:"16 18 22 12 16 6",key:"z7tu5w"}],["polyline",{points:"8 6 2 12 8 18",key:"1eg1df"}]])},2086:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(9224).Z)("Home",[["path",{d:"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"y5dka4"}],["polyline",{points:"9 22 9 12 15 12 15 22",key:"e2us08"}]])},8120:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(9224).Z)("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]])},8200:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(9224).Z)("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]])},3746:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(9224).Z)("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},473:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(9224).Z)("Sparkles",[["path",{d:"m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z",key:"17u4zn"}],["path",{d:"M5 3v4",key:"bklmnn"}],["path",{d:"M19 17v4",key:"iiml17"}],["path",{d:"M3 5h4",key:"nem4j1"}],["path",{d:"M17 19h4",key:"lbex7p"}]])},6064:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(9224).Z)("TrendingUp",[["polyline",{points:"22 7 13.5 15.5 8.5 10.5 2 17",key:"126l90"}],["polyline",{points:"16 7 22 7 22 13",key:"kwv8wd"}]])},782:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(9224).Z)("Trophy",[["path",{d:"M6 9H4.5a2.5 2.5 0 0 1 0-5H6",key:"17hqa7"}],["path",{d:"M18 9h1.5a2.5 2.5 0 0 0 0-5H18",key:"lmptdp"}],["path",{d:"M4 22h16",key:"57wxv0"}],["path",{d:"M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22",key:"1nw9bq"}],["path",{d:"M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22",key:"1np0yb"}],["path",{d:"M18 2H6v7a6 6 0 0 0 12 0V2Z",key:"u46fv3"}]])},8822:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(9224).Z)("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]])},9895:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(9224).Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]])},1275:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>m});var s=r(5344),a=r(3729),i=r(6700),l=r(8428),o=r(3890),n=r(3211),c=r(9895),d=r(5187),u=r(6064);/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let p=(0,r(9224).Z)("PlusCircle",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M8 12h8",key:"1wcyev"}],["path",{d:"M12 8v8",key:"napkw2"}]]);var h=r(6506);function m(){let{profile:e,loading:t}=(0,i.a)(),r=(0,l.useRouter)(),[m,x]=(0,a.useState)({myCourses:0,totalStudents:0,completedLessons:0,averageScore:0});(0,a.useEffect)(()=>{if(!t&&e){if("teacher"!==e.role&&"admin"!==e.role){r.push("/");return}y()}},[t,e]);let y=async()=>{if(!e)return;let t=(0,o.e)(),{count:r}=await t.from("courses").select("*",{count:"exact",head:!0}).eq("created_by",e.id),{count:s}=await t.from("users").select("*",{count:"exact",head:!0}).eq("role","student"),{count:a}=await t.from("user_progress").select("*",{count:"exact",head:!0}).eq("status","completed"),{data:i}=await t.from("user_progress").select("score").eq("status","completed").not("score","is",null);x({myCourses:r||0,totalStudents:s||0,completedLessons:a||0,averageScore:Math.round(i&&i.length>0?i.reduce((e,t)=>e+(t.score||0),0)/i.length:0)})};if(t||!e)return s.jsx("div",{className:"flex min-h-screen items-center justify-center",children:s.jsx("div",{className:"loading-spinner"})});if("teacher"!==e.role&&"admin"!==e.role)return s.jsx("div",{className:"flex min-h-screen items-center justify-center",children:(0,s.jsxs)("div",{className:"text-center",children:[s.jsx("h1",{className:"mb-2 text-2xl font-bold text-gray-900",children:"权限不足"}),s.jsx("p",{className:"text-gray-600",children:"你没有访问教师工作台的权限"})]})});let g=[{title:"我的课程",value:m.myCourses,icon:n.Z,color:"from-blue-400 to-blue-600"},{title:"学生总数",value:m.totalStudents,icon:c.Z,color:"from-purple-400 to-purple-600"},{title:"完成关卡",value:m.completedLessons,icon:d.Z,color:"from-green-400 to-green-600"},{title:"平均分数",value:`${m.averageScore}分`,icon:u.Z,color:"from-orange-400 to-orange-600"}],v=[{title:"创建新课程",description:"设计全新的学习内容",link:"/admin/courses/new",icon:p,color:"blue"},{title:"管理课程",description:"编辑和管理现有课程",link:"/admin/courses",icon:n.Z,color:"purple"},{title:"学生进度",description:"查看学生学习情况",link:"/teacher/students",icon:c.Z,color:"green"},{title:"数据分析",description:"查看教学数据和统计",link:"/teacher/analytics",icon:u.Z,color:"orange"}];return s.jsx("div",{className:"min-h-screen bg-gradient-to-br from-gray-50 via-white to-purple-50 p-6",children:(0,s.jsxs)("div",{className:"mx-auto max-w-7xl",children:[(0,s.jsxs)("div",{className:"mb-8",children:[s.jsx("h1",{className:"mb-2 text-3xl font-bold text-gray-900",children:"教师工作台"}),(0,s.jsxs)("p",{className:"text-gray-600",children:["欢迎, ",e.display_name||e.username," 老师!"]})]}),s.jsx("div",{className:"mb-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4",children:g.map((e,t)=>{let r=e.icon;return(0,s.jsxs)("div",{className:"overflow-hidden rounded-2xl border bg-white p-6 shadow-sm",children:[(0,s.jsxs)("div",{className:"mb-4 flex items-center justify-between",children:[s.jsx("div",{className:`flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${e.color} text-white shadow-lg`,children:s.jsx(r,{className:"h-6 w-6"})}),s.jsx("div",{className:"text-3xl font-bold text-gray-900",children:e.value})]}),s.jsx("h3",{className:"text-sm font-medium text-gray-600",children:e.title})]},t)})}),(0,s.jsxs)("div",{children:[s.jsx("h2",{className:"mb-4 text-xl font-semibold text-gray-900",children:"快捷操作"}),s.jsx("div",{className:"grid gap-4 sm:grid-cols-2",children:v.map((e,t)=>{let r=e.icon;return s.jsx(h.default,{href:e.link,children:s.jsx("div",{className:"group cursor-pointer rounded-xl border bg-white p-6 shadow-sm transition-all hover:shadow-md",children:(0,s.jsxs)("div",{className:"mb-3 flex items-center gap-3",children:[s.jsx("div",{className:`flex h-12 w-12 items-center justify-center rounded-lg bg-${e.color}-100 text-${e.color}-600`,children:s.jsx(r,{className:"h-6 w-6"})}),(0,s.jsxs)("div",{children:[s.jsx("h3",{className:"font-semibold text-gray-900",children:e.title}),s.jsx("p",{className:"text-sm text-gray-600",children:e.description})]})]})})},t)})})]})]})})}},1318:(e,t,r)=>{"use strict";r.r(t),r.d(t,{$$typeof:()=>i,__esModule:()=>a,default:()=>l});let s=(0,r(6843).createProxy)(String.raw`C:\Users\wangqiyuan\project\cursor\aicodegame\src\app\(dashboard)\teacher\page.tsx`),{__esModule:a,$$typeof:i}=s,l=s.default}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[225,253,506,923,301,700,445],()=>r(8649));module.exports=s})();