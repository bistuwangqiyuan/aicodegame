(()=>{var e={};e.id=51,e.ids=[51],e.modules={7849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},5403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},4749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},3685:e=>{"use strict";e.exports=require("http")},5687:e=>{"use strict";e.exports=require("https")},5477:e=>{"use strict";e.exports=require("punycode")},2781:e=>{"use strict";e.exports=require("stream")},7310:e=>{"use strict";e.exports=require("url")},9796:e=>{"use strict";e.exports=require("zlib")},6466:(e,t,s)=>{"use strict";s.r(t),s.d(t,{GlobalError:()=>l.a,__next_app__:()=>p,originalPathname:()=>u,pages:()=>o,routeModule:()=>m,tree:()=>n});var a=s(482),r=s(9108),i=s(2563),l=s.n(i),c=s(8300),d={};for(let e in c)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(d[e]=()=>c[e]);s.d(t,d);let n=["",{children:["(dashboard)",{children:["projects",{children:["[projectId]",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(s.bind(s,29)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\projects\\[projectId]\\page.tsx"]}]},{}]},{}]},{layout:[()=>Promise.resolve().then(s.bind(s,5021)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\layout.tsx"],"not-found":[()=>Promise.resolve().then(s.t.bind(s,9361,23)),"next/dist/client/components/not-found-error"]}]},{layout:[()=>Promise.resolve().then(s.bind(s,3933)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\layout.tsx"],error:[()=>Promise.resolve().then(s.bind(s,4117)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\error.tsx"],"not-found":[()=>Promise.resolve().then(s.t.bind(s,9361,23)),"next/dist/client/components/not-found-error"]}],o=["C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\projects\\[projectId]\\page.tsx"],u="/(dashboard)/projects/[projectId]/page",p={require:s,loadChunk:()=>Promise.resolve()},m=new a.AppPageRouteModule({definition:{kind:r.x.APP_PAGE,page:"/(dashboard)/projects/[projectId]/page",pathname:"/projects/[projectId]",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:n}})},2663:(e,t,s)=>{Promise.resolve().then(s.bind(s,7973))},3024:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(9224).Z)("ArrowLeft",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]])},3211:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(9224).Z)("BookOpen",[["path",{d:"M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z",key:"vv98re"}],["path",{d:"M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z",key:"1cyq3y"}]])},4657:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(9224).Z)("Bookmark",[["path",{d:"m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z",key:"1fy3hk"}]])},7189:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(9224).Z)("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]])},4826:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(9224).Z)("Code",[["polyline",{points:"16 18 22 12 16 6",key:"z7tu5w"}],["polyline",{points:"8 6 2 12 8 18",key:"1eg1df"}]])},3148:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(9224).Z)("Eye",[["path",{d:"M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z",key:"rwhkz3"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},1354:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(9224).Z)("Heart",[["path",{d:"M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z",key:"c3ymky"}]])},2086:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(9224).Z)("Home",[["path",{d:"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"y5dka4"}],["polyline",{points:"9 22 9 12 15 12 15 22",key:"e2us08"}]])},8120:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(9224).Z)("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]])},8200:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(9224).Z)("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]])},6135:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(9224).Z)("Send",[["path",{d:"m22 2-7 20-4-9-9-4Z",key:"1q3vgg"}],["path",{d:"M22 2 11 13",key:"nzbqef"}]])},3746:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(9224).Z)("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},9151:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(9224).Z)("Share2",[["circle",{cx:"18",cy:"5",r:"3",key:"gq8acd"}],["circle",{cx:"6",cy:"12",r:"3",key:"w7nqdw"}],["circle",{cx:"18",cy:"19",r:"3",key:"1xt0gg"}],["line",{x1:"8.59",x2:"15.42",y1:"13.51",y2:"17.49",key:"47mynk"}],["line",{x1:"15.41",x2:"8.59",y1:"6.51",y2:"10.49",key:"1n3mei"}]])},473:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(9224).Z)("Sparkles",[["path",{d:"m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z",key:"17u4zn"}],["path",{d:"M5 3v4",key:"bklmnn"}],["path",{d:"M19 17v4",key:"iiml17"}],["path",{d:"M3 5h4",key:"nem4j1"}],["path",{d:"M17 19h4",key:"lbex7p"}]])},6327:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(9224).Z)("SquarePen",[["path",{d:"M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7",key:"1m0v6g"}],["path",{d:"M18.375 2.625a2.121 2.121 0 1 1 3 3L12 15l-4 1 1-4Z",key:"1lpok0"}]])},8271:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(9224).Z)("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]])},782:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(9224).Z)("Trophy",[["path",{d:"M6 9H4.5a2.5 2.5 0 0 1 0-5H6",key:"17hqa7"}],["path",{d:"M18 9h1.5a2.5 2.5 0 0 0 0-5H18",key:"lmptdp"}],["path",{d:"M4 22h16",key:"57wxv0"}],["path",{d:"M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22",key:"1nw9bq"}],["path",{d:"M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22",key:"1np0yb"}],["path",{d:"M18 2H6v7a6 6 0 0 0 12 0V2Z",key:"u46fv3"}]])},8822:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(9224).Z)("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]])},9895:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,s(9224).Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]])},7973:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>f});var a=s(5344),r=s(3729),i=s(8428),l=s(6506),c=s(6700),d=s(3890),n=s(5094),o=s(339),u=s(3024),p=s(6327),m=s(8271),x=s(1354),h=s(4657),y=s(9151),j=s(3148),v=s(6135);function f(){let e=(0,i.useParams)(),t=(0,i.useRouter)(),{profile:s}=(0,c.a)(),{toast:f}=(0,o.pm)(),g=e.projectId,[k,_]=(0,r.useState)(null),[b,w]=(0,r.useState)([]),[Z,N]=(0,r.useState)(""),[q,M]=(0,r.useState)(!0),[z,P]=(0,r.useState)(!1),[C,H]=(0,r.useState)(!1),[S,L]=(0,r.useState)(0);(0,r.useEffect)(()=>{g&&(V(),A())},[g,s]);let V=async()=>{let e=(0,d.e)(),{data:a}=await e.from("projects").select(`
        *,
        users!projects_user_id_fkey(id, display_name, avatar_url, level)
      `).eq("id",g).single();if(!a){t.push("/community");return}_(a);let{count:r}=await e.from("project_likes").select("*",{count:"exact",head:!0}).eq("project_id",g);if(L(r||0),s){let{data:t}=await e.from("project_likes").select("id").eq("user_id",s.id).eq("project_id",g).single();P(!!t);let{data:a}=await e.from("user_bookmarks").select("id").eq("user_id",s.id).eq("project_id",g).single();H(!!a)}let{data:i}=await e.from("comments").select(`
        *,
        users!comments_user_id_fkey(display_name, avatar_url, level)
      `).eq("project_id",g).order("created_at",{ascending:!1});i&&w(i.map(e=>({id:e.id,content:e.content,created_at:e.created_at,user:{display_name:e.users.display_name||"Anonymous",avatar_url:e.users.avatar_url,level:e.users.level}}))),M(!1)},A=async()=>{let e=(0,d.e)();await e.rpc("increment_view_count",{project_id:g})},I=async()=>{if(!s){f({title:"请先登录",variant:"destructive"});return}let e=(0,d.e)();z?(await e.from("project_likes").delete().eq("user_id",s.id).eq("project_id",g),P(!1),L(S-1)):(await e.from("project_likes").insert({user_id:s.id,project_id:g}),P(!0),L(S+1))},U=async()=>{if(!s){f({title:"请先登录",variant:"destructive"});return}let e=(0,d.e)();C?(await e.from("user_bookmarks").delete().eq("user_id",s.id).eq("project_id",g),H(!1),f({title:"已取消收藏"})):(await e.from("user_bookmarks").insert({user_id:s.id,project_id:g}),H(!0),f({title:"收藏成功!"}))},E=async()=>{if(!s){f({title:"请先登录",variant:"destructive"});return}if(!Z.trim())return;let e=(0,d.e)(),{data:t,error:a}=await e.from("comments").insert({project_id:g,user_id:s.id,content:Z.trim()}).select(`
        *,
        users!comments_user_id_fkey(display_name, avatar_url, level)
      `).single();a?f({title:"评论失败",variant:"destructive"}):(N(""),V(),f({title:"评论成功!"}))},$=async()=>{if(!s||!k||k.user_id!==s.id||!confirm("确定要删除这个作品吗?"))return;let e=(0,d.e)(),{error:a}=await e.from("projects").delete().eq("id",g);a?f({title:"删除失败",variant:"destructive"}):(f({title:"作品已删除"}),t.push("/community"))};if(q||!k)return a.jsx("div",{className:"flex min-h-screen items-center justify-center",children:a.jsx("div",{className:"loading-spinner"})});let D=s?.id===k.user_id;return a.jsx("div",{className:"min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 p-6",children:(0,a.jsxs)("div",{className:"mx-auto max-w-5xl",children:[a.jsx(l.default,{href:"/community",children:(0,a.jsxs)(n.z,{variant:"ghost",className:"mb-6 gap-2",children:[a.jsx(u.Z,{className:"h-4 w-4"}),"返回社区"]})}),(0,a.jsxs)("div",{className:"mb-6 rounded-2xl border bg-white p-8 shadow-lg",children:[(0,a.jsxs)("div",{className:"mb-6 flex items-start justify-between",children:[(0,a.jsxs)("div",{className:"flex-1",children:[a.jsx("h1",{className:"mb-2 text-3xl font-bold text-gray-900",children:k.title}),a.jsx("p",{className:"text-gray-600",children:k.description})]}),D&&(0,a.jsxs)("div",{className:"flex gap-2",children:[a.jsx(l.default,{href:`/projects/${g}/edit`,children:(0,a.jsxs)(n.z,{variant:"outline",size:"sm",className:"gap-2",children:[a.jsx(p.Z,{className:"h-4 w-4"}),"编辑"]})}),(0,a.jsxs)(n.z,{variant:"outline",size:"sm",onClick:$,className:"gap-2 text-red-600",children:[a.jsx(m.Z,{className:"h-4 w-4"}),"删除"]})]})]}),(0,a.jsxs)("div",{className:"mb-6 flex items-center gap-3",children:[a.jsx("div",{className:"flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-blue-400 to-purple-400 text-lg font-semibold text-white",children:k.users.avatar_url?a.jsx("img",{src:k.users.avatar_url,alt:k.users.display_name,className:"h-full w-full rounded-full object-cover"}):k.users.display_name[0]}),(0,a.jsxs)("div",{children:[a.jsx("div",{className:"font-medium text-gray-900",children:k.users.display_name}),(0,a.jsxs)("div",{className:"text-sm text-gray-600",children:["Level ",k.users.level]})]})]}),a.jsx("div",{className:"mb-6 overflow-hidden rounded-lg border",children:a.jsx("iframe",{srcDoc:`
                <!DOCTYPE html>
                <html>
                  <head>
                    <style>${k.code_snapshot?.css||""}</style>
                  </head>
                  <body>
                    ${k.code_snapshot?.html||""}
                    <script>${k.code_snapshot?.js||""}</script>
                  </body>
                </html>
              `,className:"h-[500px] w-full bg-white",sandbox:"allow-scripts"})}),(0,a.jsxs)("div",{className:"flex items-center justify-between border-t pt-4",children:[(0,a.jsxs)("div",{className:"flex gap-3",children:[(0,a.jsxs)(n.z,{variant:z?"default":"outline",onClick:I,className:"gap-2",children:[a.jsx(x.Z,{className:z?"fill-current":""}),a.jsx("span",{children:S})]}),(0,a.jsxs)(n.z,{variant:C?"default":"outline",onClick:U,className:"gap-2",children:[a.jsx(h.Z,{className:C?"fill-current":""}),"收藏"]}),(0,a.jsxs)(n.z,{variant:"outline",className:"gap-2",children:[a.jsx(y.Z,{className:"h-4 w-4"}),"分享"]})]}),(0,a.jsxs)("div",{className:"flex items-center gap-2 text-sm text-gray-600",children:[a.jsx(j.Z,{className:"h-4 w-4"}),(0,a.jsxs)("span",{children:[k.view_count||0," 次浏览"]})]})]})]}),(0,a.jsxs)("div",{id:"comments",className:"rounded-2xl border bg-white p-8 shadow-lg",children:[(0,a.jsxs)("h2",{className:"mb-6 text-2xl font-bold text-gray-900",children:["评论 (",b.length,")"]}),s&&(0,a.jsxs)("div",{className:"mb-8",children:[a.jsx("textarea",{value:Z,onChange:e=>N(e.target.value),placeholder:"写下你的评论...",className:"w-full rounded-lg border p-4 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500",rows:3}),a.jsx("div",{className:"mt-2 flex justify-end",children:(0,a.jsxs)(n.z,{onClick:E,disabled:!Z.trim(),className:"gap-2",children:[a.jsx(v.Z,{className:"h-4 w-4"}),"发表评论"]})})]}),(0,a.jsxs)("div",{className:"space-y-4",children:[b.map(e=>(0,a.jsxs)("div",{className:"flex gap-3 border-b pb-4 last:border-b-0",children:[a.jsx("div",{className:"flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-blue-400 to-purple-400 text-sm font-semibold text-white",children:e.user.avatar_url?a.jsx("img",{src:e.user.avatar_url,alt:e.user.display_name,className:"h-full w-full rounded-full object-cover"}):e.user.display_name[0]}),(0,a.jsxs)("div",{className:"flex-1",children:[(0,a.jsxs)("div",{className:"mb-1 flex items-center gap-2",children:[a.jsx("span",{className:"font-medium text-gray-900",children:e.user.display_name}),(0,a.jsxs)("span",{className:"text-xs text-gray-500",children:["Lv",e.user.level]}),a.jsx("span",{className:"text-xs text-gray-400",children:new Date(e.created_at).toLocaleDateString()})]}),a.jsx("p",{className:"text-gray-700",children:e.content})]})]},e.id)),0===b.length&&a.jsx("p",{className:"py-8 text-center text-gray-500",children:"还没有评论,来发表第一条吧!"})]})]})]})})}},29:(e,t,s)=>{"use strict";s.r(t),s.d(t,{$$typeof:()=>i,__esModule:()=>r,default:()=>l});let a=(0,s(6843).createProxy)(String.raw`C:\Users\wangqiyuan\project\cursor\aicodegame\src\app\(dashboard)\projects\[projectId]\page.tsx`),{__esModule:r,$$typeof:i}=a,l=a.default}};var t=require("../../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),a=t.X(0,[225,253,506,923,301,700,445],()=>s(6466));module.exports=a})();