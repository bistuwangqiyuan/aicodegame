(()=>{var e={};e.id=447,e.ids=[447],e.modules={7849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},5403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},4749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},3685:e=>{"use strict";e.exports=require("http")},5687:e=>{"use strict";e.exports=require("https")},5477:e=>{"use strict";e.exports=require("punycode")},2781:e=>{"use strict";e.exports=require("stream")},7310:e=>{"use strict";e.exports=require("url")},9796:e=>{"use strict";e.exports=require("zlib")},4608:(e,t,s)=>{"use strict";s.r(t),s.d(t,{GlobalError:()=>l.a,__next_app__:()=>p,originalPathname:()=>u,pages:()=>o,routeModule:()=>m,tree:()=>d});var r=s(482),a=s(9108),i=s(2563),l=s.n(i),n=s(8300),c={};for(let e in n)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(c[e]=()=>n[e]);s.d(t,c);let d=["",{children:["(dashboard)",{children:["community",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(s.bind(s,4437)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\community\\page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(s.bind(s,5021)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\layout.tsx"],"not-found":[()=>Promise.resolve().then(s.t.bind(s,9361,23)),"next/dist/client/components/not-found-error"]}]},{layout:[()=>Promise.resolve().then(s.bind(s,3933)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\layout.tsx"],error:[()=>Promise.resolve().then(s.bind(s,4117)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\error.tsx"],"not-found":[()=>Promise.resolve().then(s.t.bind(s,9361,23)),"next/dist/client/components/not-found-error"]}],o=["C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\community\\page.tsx"],u="/(dashboard)/community/page",p={require:s,loadChunk:()=>Promise.resolve()},m=new r.AppPageRouteModule({definition:{kind:a.x.APP_PAGE,page:"/(dashboard)/community/page",pathname:"/community",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},6315:(e,t,s)=>{Promise.resolve().then(s.bind(s,5907))},5187:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(9224).Z)("Award",[["circle",{cx:"12",cy:"8",r:"6",key:"1vp47v"}],["path",{d:"M15.477 12.89 17 22l-5-3-5 3 1.523-9.11",key:"em7aur"}]])},3211:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(9224).Z)("BookOpen",[["path",{d:"M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z",key:"vv98re"}],["path",{d:"M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z",key:"1cyq3y"}]])},4657:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(9224).Z)("Bookmark",[["path",{d:"m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z",key:"1fy3hk"}]])},7189:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(9224).Z)("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]])},4826:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(9224).Z)("Code",[["polyline",{points:"16 18 22 12 16 6",key:"z7tu5w"}],["polyline",{points:"8 6 2 12 8 18",key:"1eg1df"}]])},3148:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(9224).Z)("Eye",[["path",{d:"M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z",key:"rwhkz3"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},1354:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(9224).Z)("Heart",[["path",{d:"M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z",key:"c3ymky"}]])},2086:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(9224).Z)("Home",[["path",{d:"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"y5dka4"}],["polyline",{points:"9 22 9 12 15 12 15 22",key:"e2us08"}]])},8120:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(9224).Z)("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]])},8200:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(9224).Z)("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]])},1838:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(9224).Z)("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]])},3746:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(9224).Z)("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},9151:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(9224).Z)("Share2",[["circle",{cx:"18",cy:"5",r:"3",key:"gq8acd"}],["circle",{cx:"6",cy:"12",r:"3",key:"w7nqdw"}],["circle",{cx:"18",cy:"19",r:"3",key:"1xt0gg"}],["line",{x1:"8.59",x2:"15.42",y1:"13.51",y2:"17.49",key:"47mynk"}],["line",{x1:"15.41",x2:"8.59",y1:"6.51",y2:"10.49",key:"1n3mei"}]])},473:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(9224).Z)("Sparkles",[["path",{d:"m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z",key:"17u4zn"}],["path",{d:"M5 3v4",key:"bklmnn"}],["path",{d:"M19 17v4",key:"iiml17"}],["path",{d:"M3 5h4",key:"nem4j1"}],["path",{d:"M17 19h4",key:"lbex7p"}]])},6064:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(9224).Z)("TrendingUp",[["polyline",{points:"22 7 13.5 15.5 8.5 10.5 2 17",key:"126l90"}],["polyline",{points:"16 7 22 7 22 13",key:"kwv8wd"}]])},782:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(9224).Z)("Trophy",[["path",{d:"M6 9H4.5a2.5 2.5 0 0 1 0-5H6",key:"17hqa7"}],["path",{d:"M18 9h1.5a2.5 2.5 0 0 0 0-5H18",key:"lmptdp"}],["path",{d:"M4 22h16",key:"57wxv0"}],["path",{d:"M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22",key:"1nw9bq"}],["path",{d:"M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22",key:"1np0yb"}],["path",{d:"M18 2H6v7a6 6 0 0 0 12 0V2Z",key:"u46fv3"}]])},8822:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(9224).Z)("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]])},9895:(e,t,s)=>{"use strict";s.d(t,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,s(9224).Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]])},5907:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>k});var r=s(5344),a=s(3729),i=s(6506),l=s(6700),n=s(3890),c=s(5094),d=s(339),o=s(1838),u=s(6064),p=s(7189),m=s(5187),x=s(1354);/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let h=(0,s(9224).Z)("MessageCircle",[["path",{d:"M7.9 20A9 9 0 1 0 4 16.1L2 22Z",key:"vv11sd"}]]);var y=s(3148),g=s(4657),v=s(9151);function k(){let{profile:e}=(0,l.a)(),{toast:t}=(0,d.pm)(),[s,k]=(0,a.useState)([]),[j,f]=(0,a.useState)(!0),[_,b]=(0,a.useState)("trending");(0,a.useEffect)(()=>{w()},[_,e]);let w=async()=>{let t=(0,n.e)(),s=t.from("projects").select(`
        *,
        users!projects_user_id_fkey(id, display_name, avatar_url, level),
        project_likes(count)
      `).eq("is_public",!0);"trending"===_?s=s.order("view_count",{ascending:!1}):"latest"===_?s=s.order("created_at",{ascending:!1}):"featured"===_&&(s=s.eq("is_featured",!0).order("created_at",{ascending:!1}));let{data:r,error:a}=await s.limit(20);if(r&&!a){let s=new Set,a=new Set;if(e){let{data:r}=await t.from("project_likes").select("project_id").eq("user_id",e.id),{data:i}=await t.from("user_bookmarks").select("project_id").eq("user_id",e.id);s=new Set(r?.map(e=>e.project_id)),a=new Set(i?.map(e=>e.project_id))}k(r.map(e=>({id:e.id,title:e.title,description:e.description,thumbnail_url:e.thumbnail_url,view_count:e.view_count||0,like_count:e.project_likes?.[0]?.count||0,comment_count:0,created_at:e.created_at,user:{id:e.users.id,display_name:e.users.display_name||"Anonymous",avatar_url:e.users.avatar_url,level:e.users.level},is_liked:s.has(e.id),is_bookmarked:a.has(e.id)})))}f(!1)},Z=async r=>{if(!e){t({title:"请先登录",description:"登录后即可点赞作品",variant:"destructive"});return}let a=(0,n.e)(),i=s.find(e=>e.id===r);i?.is_liked?await a.from("project_likes").delete().eq("user_id",e.id).eq("project_id",r):await a.from("project_likes").insert({user_id:e.id,project_id:r}),w()},N=async r=>{if(!e){t({title:"请先登录",description:"登录后即可收藏作品",variant:"destructive"});return}let a=(0,n.e)(),i=s.find(e=>e.id===r);i?.is_bookmarked?(await a.from("user_bookmarks").delete().eq("user_id",e.id).eq("project_id",r),t({title:"已取消收藏"})):(await a.from("user_bookmarks").insert({user_id:e.id,project_id:r}),t({title:"收藏成功!"})),w()};return r.jsx("div",{className:"min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 p-6",children:(0,r.jsxs)("div",{className:"mx-auto max-w-7xl",children:[(0,r.jsxs)("div",{className:"mb-8 flex items-center justify-between",children:[(0,r.jsxs)("div",{children:[r.jsx("h1",{className:"mb-2 text-3xl font-bold text-gray-900",children:"作品展示"}),r.jsx("p",{className:"text-gray-600",children:"发现优秀作品,获取创作灵感"})]}),r.jsx(i.default,{href:"/projects/new",children:(0,r.jsxs)(c.z,{className:"gap-2",children:[r.jsx(o.Z,{className:"h-4 w-4"}),"发布作品"]})})]}),(0,r.jsxs)("div",{className:"mb-6 flex gap-2",children:[(0,r.jsxs)(c.z,{variant:"trending"===_?"default":"outline",onClick:()=>b("trending"),className:"gap-2",children:[r.jsx(u.Z,{className:"h-4 w-4"}),"热门"]}),(0,r.jsxs)(c.z,{variant:"latest"===_?"default":"outline",onClick:()=>b("latest"),className:"gap-2",children:[r.jsx(p.Z,{className:"h-4 w-4"}),"最新"]}),(0,r.jsxs)(c.z,{variant:"featured"===_?"default":"outline",onClick:()=>b("featured"),className:"gap-2",children:[r.jsx(m.Z,{className:"h-4 w-4"}),"精选"]})]}),j?r.jsx("div",{className:"py-12 text-center",children:r.jsx("div",{className:"loading-spinner mx-auto"})}):s.length>0?r.jsx("div",{className:"grid gap-6 sm:grid-cols-2 lg:grid-cols-3",children:s.map(e=>(0,r.jsxs)("div",{className:"group overflow-hidden rounded-xl border bg-white shadow-sm transition-all hover:shadow-lg",children:[r.jsx(i.default,{href:`/projects/${e.id}`,children:r.jsx("div",{className:"aspect-video overflow-hidden bg-gradient-to-br from-blue-100 to-purple-100",children:e.thumbnail_url?r.jsx("img",{src:e.thumbnail_url,alt:e.title,className:"h-full w-full object-cover transition-transform group-hover:scale-105"}):r.jsx("div",{className:"flex h-full items-center justify-center text-4xl",children:"\uD83C\uDFA8"})})}),(0,r.jsxs)("div",{className:"p-4",children:[r.jsx(i.default,{href:`/projects/${e.id}`,children:r.jsx("h3",{className:"mb-2 line-clamp-2 text-lg font-semibold text-gray-900 hover:text-blue-600",children:e.title})}),r.jsx("p",{className:"mb-4 line-clamp-2 text-sm text-gray-600",children:e.description}),(0,r.jsxs)("div",{className:"mb-4 flex items-center gap-2",children:[r.jsx("div",{className:"flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-blue-400 to-purple-400 text-sm font-semibold text-white",children:e.user.avatar_url?r.jsx("img",{src:e.user.avatar_url,alt:e.user.display_name,className:"h-full w-full rounded-full object-cover"}):e.user.display_name[0]}),(0,r.jsxs)("div",{className:"flex-1",children:[r.jsx("div",{className:"text-sm font-medium text-gray-900",children:e.user.display_name}),(0,r.jsxs)("div",{className:"text-xs text-gray-500",children:["Level ",e.user.level]})]})]}),(0,r.jsxs)("div",{className:"flex items-center justify-between border-t pt-3",children:[(0,r.jsxs)("div",{className:"flex items-center gap-4 text-sm text-gray-600",children:[(0,r.jsxs)("button",{onClick:()=>Z(e.id),className:`flex items-center gap-1 transition-colors hover:text-red-500 ${e.is_liked?"text-red-500":""}`,children:[r.jsx(x.Z,{className:`h-4 w-4 ${e.is_liked?"fill-current":""}`}),r.jsx("span",{children:e.like_count})]}),(0,r.jsxs)(i.default,{href:`/projects/${e.id}#comments`,className:"flex items-center gap-1 hover:text-blue-600",children:[r.jsx(h,{className:"h-4 w-4"}),r.jsx("span",{children:e.comment_count})]}),(0,r.jsxs)("div",{className:"flex items-center gap-1",children:[r.jsx(y.Z,{className:"h-4 w-4"}),r.jsx("span",{children:e.view_count})]})]}),(0,r.jsxs)("div",{className:"flex gap-1",children:[r.jsx("button",{onClick:()=>N(e.id),className:`rounded p-1.5 transition-colors hover:bg-gray-100 ${e.is_bookmarked?"text-yellow-500":"text-gray-400"}`,children:r.jsx(g.Z,{className:`h-4 w-4 ${e.is_bookmarked?"fill-current":""}`})}),r.jsx("button",{className:"rounded p-1.5 text-gray-400 transition-colors hover:bg-gray-100",children:r.jsx(v.Z,{className:"h-4 w-4"})})]})]})]})]},e.id))}):(0,r.jsxs)("div",{className:"rounded-2xl border bg-white p-12 text-center shadow-lg",children:[r.jsx("div",{className:"mx-auto mb-4 text-6xl",children:"\uD83C\uDFA8"}),r.jsx("h3",{className:"mb-2 text-xl font-semibold text-gray-700",children:"暂无作品"}),r.jsx("p",{className:"text-gray-600",children:"成为第一个发布作品的人吧!"})]})]})})}},4437:(e,t,s)=>{"use strict";s.r(t),s.d(t,{$$typeof:()=>i,__esModule:()=>a,default:()=>l});let r=(0,s(6843).createProxy)(String.raw`C:\Users\wangqiyuan\project\cursor\aicodegame\src\app\(dashboard)\community\page.tsx`),{__esModule:a,$$typeof:i}=r,l=r.default}};var t=require("../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),r=t.X(0,[225,253,506,923,301,700,445],()=>s(4608));module.exports=r})();