(()=>{var e={};e.id=47,e.ids=[47],e.modules={7849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},5403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},4749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},3685:e=>{"use strict";e.exports=require("http")},5687:e=>{"use strict";e.exports=require("https")},5477:e=>{"use strict";e.exports=require("punycode")},2781:e=>{"use strict";e.exports=require("stream")},7310:e=>{"use strict";e.exports=require("url")},9796:e=>{"use strict";e.exports=require("zlib")},4364:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>l.a,__next_app__:()=>m,originalPathname:()=>h,pages:()=>d,routeModule:()=>u,tree:()=>c});var s=r(482),a=r(9108),o=r(2563),l=r.n(o),n=r(8300),i={};for(let e in n)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(i[e]=()=>n[e]);r.d(t,i);let c=["",{children:["(dashboard)",{children:["editor",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,2232)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\editor\\page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(r.bind(r,5021)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\layout.tsx"],"not-found":[()=>Promise.resolve().then(r.t.bind(r,9361,23)),"next/dist/client/components/not-found-error"]}]},{layout:[()=>Promise.resolve().then(r.bind(r,3933)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\layout.tsx"],error:[()=>Promise.resolve().then(r.bind(r,4117)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\error.tsx"],"not-found":[()=>Promise.resolve().then(r.t.bind(r,9361,23)),"next/dist/client/components/not-found-error"]}],d=["C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\editor\\page.tsx"],h="/(dashboard)/editor/page",m={require:r,loadChunk:()=>Promise.resolve()},u=new s.AppPageRouteModule({definition:{kind:a.x.APP_PAGE,page:"/(dashboard)/editor/page",pathname:"/editor",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},9962:(e,t,r)=>{Promise.resolve().then(r.bind(r,1213))},9886:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(9224).Z)("Code2",[["path",{d:"m18 16 4-4-4-4",key:"1inbqp"}],["path",{d:"m6 8-4 4 4 4",key:"15zrgr"}],["path",{d:"m14.5 4-5 16",key:"e7oirm"}]])},1222:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(9224).Z)("EyeOff",[["path",{d:"M9.88 9.88a3 3 0 1 0 4.24 4.24",key:"1jxqfv"}],["path",{d:"M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68",key:"9wicm4"}],["path",{d:"M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61",key:"1jreej"}],["line",{x1:"2",x2:"22",y1:"2",y2:"22",key:"a6p6uj"}]])},3148:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(9224).Z)("Eye",[["path",{d:"M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z",key:"rwhkz3"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},1213:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>N});var s=r(5344),a=r(3729),o=r(508),l=r(9448),n=r(5094),i=r(3158);let c=`<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <title>我的网页</title>
</head>
<body>
  <h1>Hello, World!</h1>
  <p>这是我的第一个网页</p>
</body>
</html>`,d=`body {
  font-family: Arial, sans-serif;
  padding: 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  text-align: center;
}

h1 {
  font-size: 2.5rem;
  margin-bottom: 1rem;
}

p {
  font-size: 1.2rem;
}`,h=`console.log('欢迎来到 GameCode Lab!');

// 你的JavaScript代码写在这里
document.addEventListener('DOMContentLoaded', function() {
  console.log('页面加载完成');
});`,m=(0,i.Ue)(e=>({htmlCode:c,cssCode:d,jsCode:h,theme:"vs-dark",fontSize:14,autoSave:!0,activeTab:"html",isPreviewVisible:!0,layout:"horizontal",setHtmlCode:t=>e({htmlCode:t}),setCssCode:t=>e({cssCode:t}),setJsCode:t=>e({jsCode:t}),setActiveTab:t=>e({activeTab:t}),setTheme:t=>e({theme:t}),setFontSize:t=>e({fontSize:t}),togglePreview:()=>e(e=>({isPreviewVisible:!e.isPreviewVisible})),toggleLayout:()=>e(e=>({layout:"horizontal"===e.layout?"vertical":"horizontal"})),setAutoSave:t=>e({autoSave:t}),resetCode:()=>e({htmlCode:c,cssCode:d,jsCode:h}),loadCode:(t,r,s)=>e({htmlCode:t,cssCode:r,jsCode:s})}));var u=r(9224);/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let x=(0,u.Z)("FileCode",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"m10 13-2 2 2 2",key:"17smn8"}],["path",{d:"m14 17 2-2-2-2",key:"14mezr"}]]),p=(0,u.Z)("Palette",[["circle",{cx:"13.5",cy:"6.5",r:".5",fill:"currentColor",key:"1okk4w"}],["circle",{cx:"17.5",cy:"10.5",r:".5",fill:"currentColor",key:"f64h9f"}],["circle",{cx:"8.5",cy:"7.5",r:".5",fill:"currentColor",key:"fotxhn"}],["circle",{cx:"6.5",cy:"12.5",r:".5",fill:"currentColor",key:"qy21gx"}],["path",{d:"M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z",key:"12rzf8"}]]),g=(0,u.Z)("Braces",[["path",{d:"M8 3H7a2 2 0 0 0-2 2v5a2 2 0 0 1-2 2 2 2 0 0 1 2 2v5c0 1.1.9 2 2 2h1",key:"ezmyqa"}],["path",{d:"M16 21h1a2 2 0 0 0 2-2v-5c0-1.1.9-2 2-2a2 2 0 0 1-2-2V5a2 2 0 0 0-2-2h-1",key:"e1hn23"}]]);var f=r(9886);/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let y=(0,u.Z)("PanelsTopLeft",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M3 9h18",key:"1pudct"}],["path",{d:"M9 21V9",key:"1oto5p"}]]);var b=r(1222),v=r(3148);/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let w=(0,u.Z)("RotateCcw",[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]]);var j=r(3746),C=r(1498);function N(){let{htmlCode:e,cssCode:t,jsCode:r,activeTab:i,isPreviewVisible:c,layout:d,theme:h,setHtmlCode:u,setCssCode:N,setJsCode:k,setActiveTab:z,togglePreview:P,toggleLayout:q,resetCode:S}=m(),[M,Z]=(0,a.useState)(!1),L=async()=>{Z(!0),console.log("保存代码..."),setTimeout(()=>{Z(!1),alert("代码已保存!")},1e3)};return(0,s.jsxs)("div",{className:"flex h-screen flex-col bg-gray-100",children:[(0,s.jsxs)("div",{className:"flex items-center justify-between border-b bg-white px-4 py-3 shadow-sm",children:[(0,s.jsxs)("div",{className:"flex items-center gap-4",children:[(0,s.jsxs)("div",{className:"flex items-center gap-2",children:[s.jsx(f.Z,{className:"h-6 w-6 text-blue-600"}),s.jsx("h1",{className:"text-xl font-bold text-gray-900",children:"代码编辑器"})]}),s.jsx("div",{className:"flex gap-1 rounded-lg border p-1",children:[{id:"html",label:"HTML",icon:x,color:"text-orange-500"},{id:"css",label:"CSS",icon:p,color:"text-blue-500"},{id:"javascript",label:"JavaScript",icon:g,color:"text-yellow-500"}].map(e=>{let t=e.icon;return(0,s.jsxs)("button",{onClick:()=>z(e.id),className:`flex items-center gap-2 rounded px-3 py-1.5 text-sm font-medium transition-colors ${i===e.id?"bg-blue-500 text-white":"text-gray-600 hover:bg-gray-100"}`,children:[s.jsx(t,{className:`h-4 w-4 ${i===e.id?"":e.color}`}),s.jsx("span",{children:e.label})]},e.id)})})]}),(0,s.jsxs)("div",{className:"flex items-center gap-2",children:[s.jsx(n.z,{size:"sm",variant:"ghost",onClick:q,title:"切换布局",children:s.jsx(y,{className:"h-4 w-4"})}),s.jsx(n.z,{size:"sm",variant:"ghost",onClick:P,title:c?"隐藏预览":"显示预览",children:c?s.jsx(b.Z,{className:"h-4 w-4"}):s.jsx(v.Z,{className:"h-4 w-4"})}),s.jsx(n.z,{size:"sm",variant:"ghost",onClick:S,title:"重置代码",children:s.jsx(w,{className:"h-4 w-4"})}),s.jsx(n.z,{size:"sm",variant:"ghost",title:"设置",children:s.jsx(j.Z,{className:"h-4 w-4"})}),(0,s.jsxs)(n.z,{size:"sm",onClick:L,disabled:M,className:"gap-2",children:[s.jsx(C.Z,{className:"h-4 w-4"}),s.jsx("span",{children:M?"保存中...":"保存"})]})]})]}),(0,s.jsxs)("div",{className:`flex flex-1 overflow-hidden ${"horizontal"===d?"flex-row":"flex-col"}`,children:[(0,s.jsxs)("div",{className:`flex flex-col ${c?"horizontal"===d?"w-1/2":"h-1/2":"w-full"} border-r`,children:["html"===i&&s.jsx(o.p,{language:"html",value:e,onChange:u,theme:h}),"css"===i&&s.jsx(o.p,{language:"css",value:t,onChange:N,theme:h}),"javascript"===i&&s.jsx(o.p,{language:"javascript",value:r,onChange:k,theme:h})]}),c&&s.jsx("div",{className:`${"horizontal"===d?"w-1/2":"h-1/2"}`,children:s.jsx(l.T,{htmlCode:e,cssCode:t,jsCode:r,autoRefresh:!0,refreshDelay:1e3})})]})]})}},508:(e,t,r)=>{"use strict";r.d(t,{p:()=>l});var s=r(5344),a=r(3729),o=r(4127);function l({language:e,value:t,onChange:r,readOnly:l=!1,height:n="100%",theme:i="vs-dark"}){let c=(0,a.useRef)(null),[d,h]=(0,a.useState)(!1),m=()=>{c.current&&c.current.getAction("editor.action.formatDocument")?.run()};return(0,a.useEffect)(()=>{d&&window.formatCode&&(window.formatCode[e]=m)},[d,e]),s.jsx("div",{className:"h-full w-full overflow-hidden rounded-lg border border-gray-200",children:s.jsx(o.ZP,{height:n,language:e,value:t,onChange:e=>{void 0!==e&&r(e)},onMount:(t,r)=>{c.current=t,t.updateOptions({fontSize:14,lineNumbers:"on",minimap:{enabled:!1},automaticLayout:!0,scrollBeyondLastLine:!1,wordWrap:"on",tabSize:2,insertSpaces:!0,formatOnPaste:!0,formatOnType:!0,readOnly:l}),"html"===e&&r.languages.html.htmlDefaults.setOptions({format:{tabSize:2,insertSpaces:!0,wrapLineLength:120,unformatted:"wbr",contentUnformatted:"pre,code,textarea",indentInnerHtml:!1,preserveNewLines:!0,maxPreserveNewLines:2,indentHandlebars:!1,endWithNewline:!1,extraLiners:"head, body, /html",wrapAttributes:"auto"}}),h(!0)},theme:i,loading:s.jsx("div",{className:"flex h-full items-center justify-center bg-gray-900",children:(0,s.jsxs)("div",{className:"text-center",children:[s.jsx("div",{className:"loading-spinner mx-auto mb-2"}),s.jsx("p",{className:"text-sm text-gray-400",children:"加载编辑器..."})]})}),options:{readOnly:l,contextmenu:!0,folding:!0,lineDecorationsWidth:10,lineNumbersMinChars:3,renderLineHighlight:"all",scrollbar:{vertical:"visible",horizontal:"visible",verticalScrollbarSize:10,horizontalScrollbarSize:10}}})})}},9448:(e,t,r)=>{"use strict";r.d(t,{T:()=>m});var s=r(5344),a=r(3729),o=r(6588),l=r(9138),n=r(3101),i=r(3733),c=r(5560),d=r(4540),h=r(5094);function m({htmlCode:e,cssCode:t,jsCode:r,autoRefresh:m=!0,refreshDelay:u=1e3}){let x=(0,a.useRef)(null),[p,g]=(0,a.useState)(!1),[f,y]=(0,a.useState)("desktop"),[b,v]=(0,a.useState)([]),w=(0,a.useRef)(),j=()=>`
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Preview</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: system-ui, -apple-system, sans-serif; }
    ${t}
  </style>
</head>
<body>
  ${e}
  <script>
    // 拦截console.log并发送到父窗口
    (function() {
      const originalLog = console.log;
      const originalError = console.error;
      const originalWarn = console.warn;

      console.log = function(...args) {
        originalLog.apply(console, args);
        window.parent.postMessage({
          type: 'console',
          method: 'log',
          args: args.map(arg => String(arg))
        }, '*');
      };

      console.error = function(...args) {
        originalError.apply(console, args);
        window.parent.postMessage({
          type: 'console',
          method: 'error',
          args: args.map(arg => String(arg))
        }, '*');
      };

      console.warn = function(...args) {
        originalWarn.apply(console, args);
        window.parent.postMessage({
          type: 'console',
          method: 'warn',
          args: args.map(arg => String(arg))
        }, '*');
      };

      // 捕获运行时错误
      window.onerror = function(message, source, lineno, colno, error) {
        window.parent.postMessage({
          type: 'console',
          method: 'error',
          args: [\`Error: \${message} at line \${lineno}\`]
        }, '*');
        return false;
      };
    })();

    // 用户代码
    try {
      ${r}
    } catch (error) {
      console.error('执行错误:', error.message);
    }
  </script>
</body>
</html>
    `,C=()=>{if(!x.current)return;let e=j(),t=new Blob([e],{type:"text/html"});URL.createObjectURL(t),x.current.srcdoc=e,v([])};return(0,a.useEffect)(()=>{if(m)return w.current&&clearTimeout(w.current),w.current=setTimeout(()=>{C()},u),()=>{w.current&&clearTimeout(w.current)}},[e,t,r,m,u]),(0,a.useEffect)(()=>{let e=e=>{if("console"===e.data.type){let{method:t,args:r}=e.data,s=`[${t}] ${r.join(" ")}`;v(e=>[...e,s])}};return window.addEventListener("message",e),()=>window.removeEventListener("message",e)},[]),(0,s.jsxs)("div",{className:`flex h-full flex-col ${p?"fixed inset-0 z-50 bg-white":""}`,children:[(0,s.jsxs)("div",{className:"flex items-center justify-between border-b bg-gray-50 px-4 py-2",children:[(0,s.jsxs)("div",{className:"flex items-center gap-2",children:[s.jsx("span",{className:"text-sm font-medium text-gray-700",children:"预览"}),(0,s.jsxs)("div",{className:"flex gap-1 rounded-lg border p-1",children:[s.jsx("button",{onClick:()=>y("mobile"),className:`rounded p-1 ${"mobile"===f?"bg-blue-500 text-white":"text-gray-600 hover:bg-gray-200"}`,title:"手机视图",children:s.jsx(o.Z,{className:"h-4 w-4"})}),s.jsx("button",{onClick:()=>y("tablet"),className:`rounded p-1 ${"tablet"===f?"bg-blue-500 text-white":"text-gray-600 hover:bg-gray-200"}`,title:"平板视图",children:s.jsx(l.Z,{className:"h-4 w-4"})}),s.jsx("button",{onClick:()=>y("desktop"),className:`rounded p-1 ${"desktop"===f?"bg-blue-500 text-white":"text-gray-600 hover:bg-gray-200"}`,title:"桌面视图",children:s.jsx(n.Z,{className:"h-4 w-4"})})]})]}),(0,s.jsxs)("div",{className:"flex items-center gap-2",children:[s.jsx(h.z,{size:"sm",variant:"ghost",onClick:C,children:s.jsx(i.Z,{className:"h-4 w-4"})}),s.jsx(h.z,{size:"sm",variant:"ghost",onClick:()=>{g(!p)},children:p?s.jsx(c.Z,{className:"h-4 w-4"}):s.jsx(d.Z,{className:"h-4 w-4"})})]})]}),s.jsx("div",{className:"flex-1 overflow-hidden bg-white p-4",children:s.jsx("div",{className:"mx-auto h-full overflow-auto rounded-lg border bg-white shadow-sm",style:{width:(()=>{switch(f){case"mobile":return"375px";case"tablet":return"768px";default:return"100%"}})()},children:s.jsx("iframe",{ref:x,className:"h-full w-full border-0",sandbox:"allow-scripts allow-forms allow-modals allow-pointer-lock allow-popups allow-same-origin",title:"Code Preview"})})}),b.length>0&&(0,s.jsxs)("div",{className:"border-t bg-gray-900 p-4",children:[(0,s.jsxs)("div",{className:"mb-2 flex items-center justify-between",children:[s.jsx("span",{className:"text-sm font-medium text-gray-300",children:"控制台输出"}),s.jsx("button",{onClick:()=>v([]),className:"text-xs text-gray-400 hover:text-white",children:"清空"})]}),s.jsx("div",{className:"max-h-32 overflow-y-auto rounded bg-black p-2 font-mono text-xs",children:b.map((e,t)=>s.jsx("div",{className:`mb-1 ${e.includes("[error]")?"text-red-400":e.includes("[warn]")?"text-yellow-400":"text-green-400"}`,children:e},t))})]})]})}},2232:(e,t,r)=>{"use strict";r.r(t),r.d(t,{$$typeof:()=>o,__esModule:()=>a,default:()=>l});let s=(0,r(6843).createProxy)(String.raw`C:\Users\wangqiyuan\project\cursor\aicodegame\src\app\(dashboard)\editor\page.tsx`),{__esModule:a,$$typeof:o}=s,l=s.default}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[225,253,506,923,798,301,700,445],()=>r(4364));module.exports=s})();