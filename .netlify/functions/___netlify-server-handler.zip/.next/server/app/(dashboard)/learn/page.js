(()=>{var e={};e.id=401,e.ids=[401],e.modules={7849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},5403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},4749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},3685:e=>{"use strict";e.exports=require("http")},5687:e=>{"use strict";e.exports=require("https")},5477:e=>{"use strict";e.exports=require("punycode")},2781:e=>{"use strict";e.exports=require("stream")},7310:e=>{"use strict";e.exports=require("url")},9796:e=>{"use strict";e.exports=require("zlib")},7635:(e,s,t)=>{"use strict";t.r(s),t.d(s,{GlobalError:()=>i.a,__next_app__:()=>x,originalPathname:()=>u,pages:()=>c,routeModule:()=>m,tree:()=>o});var r=t(5539),a=t(5205),l=t(8464),i=t.n(l),n=t(1088),d={};for(let e in n)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(d[e]=()=>n[e]);t.d(s,d);let o=["",{children:["(dashboard)",{children:["learn",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(t.bind(t,2564)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\learn\\page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(t.bind(t,2749)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\layout.tsx"],"not-found":[()=>Promise.resolve().then(t.t.bind(t,306,23)),"next/dist/client/components/not-found-error"]}]},{layout:[()=>Promise.resolve().then(t.bind(t,1330)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\layout.tsx"],error:[()=>Promise.resolve().then(t.bind(t,6073)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\error.tsx"],"not-found":[()=>Promise.resolve().then(t.t.bind(t,306,23)),"next/dist/client/components/not-found-error"]}],c=["C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\learn\\page.tsx"],u="/(dashboard)/learn/page",x={require:t,loadChunk:()=>Promise.resolve()},m=new r.AppPageRouteModule({definition:{kind:a.x.APP_PAGE,page:"/(dashboard)/learn/page",pathname:"/learn",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:o}})},4182:(e,s,t)=>{Promise.resolve().then(t.bind(t,4306))},6511:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Award",[["circle",{cx:"12",cy:"8",r:"6",key:"1vp47v"}],["path",{d:"M15.477 12.89 17 22l-5-3-5 3 1.523-9.11",key:"em7aur"}]])},5933:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("BookOpen",[["path",{d:"M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z",key:"vv98re"}],["path",{d:"M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z",key:"1cyq3y"}]])},3649:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("CheckCircle",[["path",{d:"M22 11.08V12a10 10 0 1 1-5.93-9.14",key:"g774vq"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]])},6179:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]])},2195:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Code",[["polyline",{points:"16 18 22 12 16 6",key:"z7tu5w"}],["polyline",{points:"8 6 2 12 8 18",key:"1eg1df"}]])},4430:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Home",[["path",{d:"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"y5dka4"}],["polyline",{points:"9 22 9 12 15 12 15 22",key:"e2us08"}]])},6217:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Lock",[["rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2",key:"1w4ew1"}],["path",{d:"M7 11V7a5 5 0 0 1 10 0v4",key:"fwvmzm"}]])},5148:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]])},8852:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]])},8801:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},4707:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Sparkles",[["path",{d:"m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z",key:"17u4zn"}],["path",{d:"M5 3v4",key:"bklmnn"}],["path",{d:"M19 17v4",key:"iiml17"}],["path",{d:"M3 5h4",key:"nem4j1"}],["path",{d:"M17 19h4",key:"lbex7p"}]])},4177:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("TrendingUp",[["polyline",{points:"22 7 13.5 15.5 8.5 10.5 2 17",key:"126l90"}],["polyline",{points:"16 7 22 7 22 13",key:"kwv8wd"}]])},760:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Trophy",[["path",{d:"M6 9H4.5a2.5 2.5 0 0 1 0-5H6",key:"17hqa7"}],["path",{d:"M18 9h1.5a2.5 2.5 0 0 0 0-5H18",key:"lmptdp"}],["path",{d:"M4 22h16",key:"57wxv0"}],["path",{d:"M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22",key:"1nw9bq"}],["path",{d:"M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22",key:"1np0yb"}],["path",{d:"M18 2H6v7a6 6 0 0 0 12 0V2Z",key:"u46fv3"}]])},2643:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]])},1809:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]])},2883:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Zap",[["polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2",key:"45s27k"}]])},4306:(e,s,t)=>{"use strict";t.r(s),t.d(s,{default:()=>g});var r=t(7639),a=t(2286),l=t(2034),i=t(7438),n=t(9302),d=t(4099),o=t(5615),c=t(4177),u=t(3649);/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let x=(0,t(5360).Z)("PlayCircle",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polygon",{points:"10 8 16 12 10 16 10 8",key:"1cimsy"}]]);var m=t(6217),p=t(5933),h=t(6511),y=t(7078);function g(){let{profile:e,loading:s}=(0,i.a)(),[t,g]=(0,a.useState)([]),[v,f]=(0,a.useState)(!0);(0,a.useEffect)(()=>{e&&b()},[e]);let b=async()=>{let s=(0,n.e)(),{data:t}=await s.from("courses").select(`
        id,
        title,
        description,
        level,
        order,
        lessons:lessons(count)
      `).eq("is_published",!0).order("level").order("order");t&&e&&g(await Promise.all(t.map(async t=>{let{data:r}=await s.from("lessons").select("id, xp_reward").eq("course_id",t.id),a=r?.map(e=>e.id)||[],l=r?.reduce((e,s)=>e+s.xp_reward,0)||0,{count:i}=await s.from("user_progress").select("*",{count:"exact",head:!0}).eq("user_id",e.id).in("lesson_id",a).eq("status","completed");return{id:t.id,title:t.title,description:t.description,level:t.level,order:t.order,lessonCount:r?.length||0,completedCount:i||0,totalXP:l}}))),f(!1)};if(s||!e)return r.jsx("div",{className:"flex min-h-screen items-center justify-center",children:r.jsx("div",{className:"loading-spinner"})});let j=(0,y.IN)(e.xp),w=e=>["\uD83D\uDCDD","\uD83C\uDFA8","⚡","\uD83D\uDD27","\uD83D\uDE80"][e-1]||"\uD83D\uDCDA",k=e=>["from-orange-400 to-red-400","from-purple-400 to-pink-400","from-yellow-400 to-orange-400","from-green-400 to-teal-400","from-blue-400 to-cyan-400"][e-1]||"from-gray-400 to-gray-500";return r.jsx("div",{className:"min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 p-6",children:(0,r.jsxs)("div",{className:"mx-auto max-w-6xl",children:[(0,r.jsxs)("div",{className:"mb-8 rounded-2xl border bg-white p-6 shadow-lg",children:[(0,r.jsxs)("div",{className:"mb-4 flex items-center justify-between",children:[(0,r.jsxs)("div",{children:[r.jsx("h1",{className:"mb-2 text-3xl font-bold text-gray-900",children:"学习中心"}),r.jsx("p",{className:"text-gray-600",children:"选择课程,开始你的编程之旅!"})]}),(0,r.jsxs)("div",{className:"text-right",children:[r.jsx("div",{className:"mb-1 text-sm text-gray-600",children:"你的进度"}),(0,r.jsxs)("div",{className:"text-2xl font-bold text-blue-600",children:["Level ",e.level]})]})]}),r.jsx(o.P,{currentXP:j.currentXP,nextLevelXP:j.nextLevelXP,level:e.level,size:"lg"})]}),r.jsx("div",{className:"mb-6 rounded-lg border-l-4 border-blue-500 bg-blue-50 p-4",children:(0,r.jsxs)("div",{className:"flex items-start gap-3",children:[r.jsx(c.Z,{className:"mt-0.5 h-5 w-5 shrink-0 text-blue-600"}),(0,r.jsxs)("div",{children:[r.jsx("h3",{className:"font-semibold text-blue-900",children:"学习路径建议"}),r.jsx("p",{className:"mt-1 text-sm text-blue-700",children:"建议按照 Level 1 → Level 5 的顺序学习,每个 Level 完成后自动解锁下一个。完成关卡可以获得 XP 和金币奖励!"})]})]})}),v?r.jsx("div",{className:"py-12 text-center",children:r.jsx("div",{className:"loading-spinner mx-auto"})}):t.length>0?r.jsx("div",{className:"space-y-6",children:t.map((e,s)=>{let a=e.lessonCount>0?e.completedCount/e.lessonCount*100:0,i=e.completedCount===e.lessonCount&&e.lessonCount>0,n=s>0&&t[s-1].completedCount<t[s-1].lessonCount,o=e.completedCount>0&&!i;return(0,r.jsxs)("div",{className:`group relative overflow-hidden rounded-2xl border-2 bg-white shadow-lg transition-all ${n?"border-gray-300 opacity-60":i?"border-green-500 hover:shadow-xl":"border-blue-300 hover:scale-[1.02] hover:shadow-xl"}`,children:[r.jsx("div",{className:`absolute right-0 top-0 h-full w-1/3 bg-gradient-to-l ${k(e.level)} opacity-10`}),r.jsx("div",{className:"relative p-8",children:(0,r.jsxs)("div",{className:"flex items-start gap-6",children:[r.jsx("div",{className:`flex h-20 w-20 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br ${k(e.level)} text-4xl shadow-lg`,children:w(e.level)}),(0,r.jsxs)("div",{className:"flex-1",children:[(0,r.jsxs)("div",{className:"mb-2 flex items-center gap-3",children:[(0,r.jsxs)("span",{className:"rounded-full bg-blue-100 px-3 py-1 text-sm font-medium text-blue-700",children:["Level ",e.level]}),i&&(0,r.jsxs)("span",{className:"flex items-center gap-1 rounded-full bg-green-100 px-3 py-1 text-sm font-medium text-green-700",children:[r.jsx(u.Z,{className:"h-4 w-4"}),"已完成"]}),o&&(0,r.jsxs)("span",{className:"flex items-center gap-1 rounded-full bg-yellow-100 px-3 py-1 text-sm font-medium text-yellow-700",children:[r.jsx(x,{className:"h-4 w-4"}),"进行中"]}),n&&(0,r.jsxs)("span",{className:"flex items-center gap-1 rounded-full bg-gray-100 px-3 py-1 text-sm font-medium text-gray-600",children:[r.jsx(m.Z,{className:"h-4 w-4"}),"未解锁"]})]}),r.jsx("h2",{className:"mb-2 text-2xl font-bold text-gray-900",children:e.title}),r.jsx("p",{className:"mb-4 text-gray-600",children:e.description}),(0,r.jsxs)("div",{className:"mb-4",children:[(0,r.jsxs)("div",{className:"mb-2 flex items-center justify-between text-sm",children:[(0,r.jsxs)("span",{className:"text-gray-600",children:["进度: ",e.completedCount," / ",e.lessonCount," 关卡"]}),(0,r.jsxs)("span",{className:"font-medium text-blue-600",children:[Math.round(a),"%"]})]}),r.jsx("div",{className:"h-2 overflow-hidden rounded-full bg-gray-200",children:r.jsx("div",{className:"h-full rounded-full bg-gradient-to-r from-blue-500 to-cyan-500 transition-all duration-500",style:{width:`${a}%`}})})]}),(0,r.jsxs)("div",{className:"flex items-center justify-between",children:[(0,r.jsxs)("div",{className:"flex items-center gap-4 text-sm text-gray-600",children:[(0,r.jsxs)("div",{className:"flex items-center gap-1",children:[r.jsx(p.Z,{className:"h-4 w-4"}),(0,r.jsxs)("span",{children:[e.lessonCount," 关卡"]})]}),(0,r.jsxs)("div",{className:"flex items-center gap-1",children:[r.jsx(h.Z,{className:"h-4 w-4 text-yellow-500"}),(0,r.jsxs)("span",{children:[e.totalXP," XP"]})]})]}),r.jsx(l.default,{href:n?"#":`/learn/${e.id}`,children:r.jsx(d.z,{disabled:n,className:i?"bg-green-600 hover:bg-green-700":"",children:n?"完成上一个课程以解锁":i?"复习课程":o?"继续学习":"开始学习"})})]})]})]})})]},e.id)})}):(0,r.jsxs)("div",{className:"rounded-2xl border bg-white p-12 text-center shadow-lg",children:[r.jsx(p.Z,{className:"mx-auto mb-4 h-16 w-16 text-gray-400"}),r.jsx("h3",{className:"mb-2 text-xl font-semibold text-gray-700",children:"暂无课程"}),r.jsx("p",{className:"text-gray-600",children:"课程内容正在准备中,敬请期待!"})]})]})})}},5615:(e,s,t)=>{"use strict";t.d(s,{P:()=>i});var r=t(7639),a=t(7078),l=t(2883);function i({currentXP:e,nextLevelXP:s,level:t,showNumbers:i=!0,size:n="md"}){let d=e/s*100;return(0,r.jsxs)("div",{className:"w-full",children:[i&&(0,r.jsxs)("div",{className:"mb-2 flex items-center justify-between text-sm",children:[(0,r.jsxs)("div",{className:"flex items-center gap-2",children:[r.jsx(l.Z,{className:"h-4 w-4 text-yellow-500"}),(0,r.jsxs)("span",{className:"font-medium text-gray-700",children:["Level ",t]})]}),(0,r.jsxs)("span",{className:"text-gray-600",children:[(0,a.uf)(e)," / ",(0,a.uf)(s)," XP"]})]}),r.jsx("div",{className:`w-full overflow-hidden rounded-full bg-gray-200 ${{sm:"h-2",md:"h-3",lg:"h-4"}[n]}`,children:r.jsx("div",{className:"xp-bar-fill h-full rounded-full bg-gradient-to-r from-blue-500 to-cyan-500 transition-all duration-500",style:{width:`${Math.min(d,100)}%`},children:r.jsx("div",{className:"h-full w-full animate-pulse bg-white/20"})})}),i&&(0,r.jsxs)("div",{className:"mt-1 text-right text-xs text-gray-500",children:[Math.round(d),"% 至下一级"]})]})}},2564:(e,s,t)=>{"use strict";t.r(s),t.d(s,{$$typeof:()=>l,__esModule:()=>a,default:()=>i});let r=(0,t(9279).createProxy)(String.raw`C:\Users\wangqiyuan\project\cursor\aicodegame\src\app\(dashboard)\learn\page.tsx`),{__esModule:a,$$typeof:l}=r,i=r.default}};var s=require("../../../webpack-runtime.js");s.C(e);var t=e=>s(s.s=e),r=s.X(0,[389,213,499,569,150,438,463],()=>t(7635));module.exports=r})();