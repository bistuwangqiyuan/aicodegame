(()=>{var e={};e.id=764,e.ids=[764],e.modules={7849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},5403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},4749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},3685:e=>{"use strict";e.exports=require("http")},5687:e=>{"use strict";e.exports=require("https")},5477:e=>{"use strict";e.exports=require("punycode")},2781:e=>{"use strict";e.exports=require("stream")},7310:e=>{"use strict";e.exports=require("url")},9796:e=>{"use strict";e.exports=require("zlib")},9001:(e,s,t)=>{"use strict";t.r(s),t.d(s,{GlobalError:()=>i.a,__next_app__:()=>p,originalPathname:()=>u,pages:()=>o,routeModule:()=>x,tree:()=>c});var r=t(5539),a=t(5205),l=t(8464),i=t.n(l),n=t(1088),d={};for(let e in n)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(d[e]=()=>n[e]);t.d(s,d);let c=["",{children:["(dashboard)",{children:["learn",{children:["[courseId]",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(t.bind(t,3285)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\learn\\[courseId]\\page.tsx"]}]},{}]},{}]},{layout:[()=>Promise.resolve().then(t.bind(t,2749)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\layout.tsx"],"not-found":[()=>Promise.resolve().then(t.t.bind(t,306,23)),"next/dist/client/components/not-found-error"]}]},{layout:[()=>Promise.resolve().then(t.bind(t,1330)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\layout.tsx"],error:[()=>Promise.resolve().then(t.bind(t,6073)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\error.tsx"],"not-found":[()=>Promise.resolve().then(t.t.bind(t,306,23)),"next/dist/client/components/not-found-error"]}],o=["C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\learn\\[courseId]\\page.tsx"],u="/(dashboard)/learn/[courseId]/page",p={require:t,loadChunk:()=>Promise.resolve()},x=new r.AppPageRouteModule({definition:{kind:a.x.APP_PAGE,page:"/(dashboard)/learn/[courseId]/page",pathname:"/learn/[courseId]",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},7389:(e,s,t)=>{Promise.resolve().then(t.bind(t,6413))},2038:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("ArrowLeft",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]])},6511:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Award",[["circle",{cx:"12",cy:"8",r:"6",key:"1vp47v"}],["path",{d:"M15.477 12.89 17 22l-5-3-5 3 1.523-9.11",key:"em7aur"}]])},5933:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("BookOpen",[["path",{d:"M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z",key:"vv98re"}],["path",{d:"M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z",key:"1cyq3y"}]])},3649:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("CheckCircle",[["path",{d:"M22 11.08V12a10 10 0 1 1-5.93-9.14",key:"g774vq"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]])},6179:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]])},2195:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Code",[["polyline",{points:"16 18 22 12 16 6",key:"z7tu5w"}],["polyline",{points:"8 6 2 12 8 18",key:"1eg1df"}]])},4430:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Home",[["path",{d:"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"y5dka4"}],["polyline",{points:"9 22 9 12 15 12 15 22",key:"e2us08"}]])},6217:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Lock",[["rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2",key:"1w4ew1"}],["path",{d:"M7 11V7a5 5 0 0 1 10 0v4",key:"fwvmzm"}]])},5148:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]])},8852:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]])},8801:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},4707:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Sparkles",[["path",{d:"m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z",key:"17u4zn"}],["path",{d:"M5 3v4",key:"bklmnn"}],["path",{d:"M19 17v4",key:"iiml17"}],["path",{d:"M3 5h4",key:"nem4j1"}],["path",{d:"M17 19h4",key:"lbex7p"}]])},760:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Trophy",[["path",{d:"M6 9H4.5a2.5 2.5 0 0 1 0-5H6",key:"17hqa7"}],["path",{d:"M18 9h1.5a2.5 2.5 0 0 0 0-5H18",key:"lmptdp"}],["path",{d:"M4 22h16",key:"57wxv0"}],["path",{d:"M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22",key:"1nw9bq"}],["path",{d:"M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22",key:"1np0yb"}],["path",{d:"M18 2H6v7a6 6 0 0 0 12 0V2Z",key:"u46fv3"}]])},2643:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]])},1809:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]])},2883:(e,s,t)=>{"use strict";t.d(s,{Z:()=>r});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,t(5360).Z)("Zap",[["polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2",key:"45s27k"}]])},6413:(e,s,t)=>{"use strict";t.r(s),t.d(s,{default:()=>g});var r=t(7639),a=t(2286),l=t(8321),i=t(2034),n=t(7438),d=t(9302),c=t(4099),o=t(2038),u=t(3649),p=t(6217),x=t(2883),h=t(6511),m=t(6179);/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let y=(0,t(5360).Z)("Play",[["polygon",{points:"5 3 19 12 5 21 5 3",key:"191637"}]]);function g(){let e=(0,l.useParams)(),s=(0,l.useRouter)(),{profile:t}=(0,n.a)(),g=e.courseId,[f,v]=(0,a.useState)(null),[j,b]=(0,a.useState)([]),[k,w]=(0,a.useState)(!0);(0,a.useEffect)(()=>{t&&g&&Z()},[t,g]);let Z=async()=>{let e=(0,d.e)(),{data:r}=await e.from("courses").select("*").eq("id",g).single();if(!r){s.push("/learn");return}v(r);let{data:a}=await e.from("lessons").select("*").eq("course_id",g).order("order");if(a&&t){let{data:s}=await e.from("user_progress").select("*").eq("user_id",t.id).in("lesson_id",a.map(e=>e.id)),r=new Map(s?.map(e=>[e.lesson_id,e])||[]);b(a.map((e,s)=>{let t=r.get(e.id),l="locked";if(0===s)l=t?.status||"in_progress";else{let e=r.get(a[s-1].id);e?.status==="completed"&&(l=t?.status||"in_progress")}return{id:e.id,title:e.title,description:e.description,order:e.order,xp_reward:e.xp_reward,coin_reward:e.coin_reward,difficulty:e.difficulty,status:l,score:t?.score}}))}w(!1)};if(k||!f)return r.jsx("div",{className:"flex min-h-screen items-center justify-center",children:r.jsx("div",{className:"loading-spinner"})});let N=e=>{switch(e){case"easy":return"text-green-600 bg-green-100";case"medium":return"text-yellow-600 bg-yellow-100";case"hard":return"text-red-600 bg-red-100";default:return"text-gray-600 bg-gray-100"}},q=j.filter(e=>"completed"===e.status).length,_=q/j.length*100;return r.jsx("div",{className:"min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 p-6",children:(0,r.jsxs)("div",{className:"mx-auto max-w-4xl",children:[r.jsx(i.default,{href:"/learn",children:(0,r.jsxs)(c.z,{variant:"ghost",className:"mb-6 gap-2",children:[r.jsx(o.Z,{className:"h-4 w-4"}),"返回学习中心"]})}),(0,r.jsxs)("div",{className:"mb-8 rounded-2xl border bg-white p-8 shadow-lg",children:[r.jsx("div",{className:"mb-4 flex items-start justify-between",children:(0,r.jsxs)("div",{children:[(0,r.jsxs)("span",{className:"mb-2 inline-block rounded-full bg-blue-100 px-3 py-1 text-sm font-medium text-blue-700",children:["Level ",f.level]}),r.jsx("h1",{className:"mb-2 text-3xl font-bold text-gray-900",children:f.title}),r.jsx("p",{className:"text-gray-600",children:f.description})]})}),(0,r.jsxs)("div",{className:"mb-4",children:[(0,r.jsxs)("div",{className:"mb-2 flex items-center justify-between text-sm",children:[(0,r.jsxs)("span",{className:"text-gray-600",children:["完成进度: ",q," / ",j.length," 关卡"]}),(0,r.jsxs)("span",{className:"font-medium text-blue-600",children:[Math.round(_),"%"]})]}),r.jsx("div",{className:"h-3 overflow-hidden rounded-full bg-gray-200",children:r.jsx("div",{className:"h-full rounded-full bg-gradient-to-r from-blue-500 to-cyan-500 transition-all duration-500",style:{width:`${_}%`}})})]})]}),r.jsx("div",{className:"space-y-4",children:j.map((e,s)=>{let t="locked"===e.status,a="completed"===e.status;return r.jsx("div",{className:`group rounded-xl border-2 bg-white p-6 shadow-sm transition-all ${t?"border-gray-200 opacity-60":a?"border-green-300 hover:shadow-md":"border-blue-300 hover:scale-[1.02] hover:shadow-md"}`,children:(0,r.jsxs)("div",{className:"flex items-center gap-6",children:[r.jsx("div",{className:`flex h-16 w-16 shrink-0 items-center justify-center rounded-xl text-2xl font-bold ${a?"bg-green-500 text-white":t?"bg-gray-200 text-gray-500":"bg-blue-500 text-white"}`,children:a?r.jsx(u.Z,{className:"h-8 w-8"}):t?r.jsx(p.Z,{className:"h-8 w-8"}):s+1}),(0,r.jsxs)("div",{className:"flex-1",children:[(0,r.jsxs)("div",{className:"mb-2 flex items-center gap-2",children:[r.jsx("h3",{className:"text-xl font-semibold text-gray-900",children:e.title}),r.jsx("span",{className:`rounded-full px-2 py-0.5 text-xs font-medium uppercase ${N(e.difficulty)}`,children:e.difficulty}),a&&e.score&&(0,r.jsxs)("span",{className:"rounded-full bg-yellow-100 px-2 py-0.5 text-xs font-medium text-yellow-700",children:[e.score,"分"]})]}),r.jsx("p",{className:"mb-3 text-gray-600",children:e.description}),(0,r.jsxs)("div",{className:"flex items-center gap-4 text-sm text-gray-600",children:[(0,r.jsxs)("div",{className:"flex items-center gap-1",children:[r.jsx(x.Z,{className:"h-4 w-4 text-yellow-500"}),(0,r.jsxs)("span",{children:["+",e.xp_reward," XP"]})]}),(0,r.jsxs)("div",{className:"flex items-center gap-1",children:[r.jsx(h.Z,{className:"h-4 w-4 text-orange-500"}),(0,r.jsxs)("span",{children:["+",e.coin_reward," 金币"]})]}),(0,r.jsxs)("div",{className:"flex items-center gap-1",children:[r.jsx(m.Z,{className:"h-4 w-4"}),r.jsx("span",{children:"约10分钟"})]})]})]}),r.jsx(i.default,{href:t?"#":`/lesson/${e.id}`,children:r.jsx(c.z,{disabled:t,variant:a?"outline":"default",className:"gap-2",children:t?(0,r.jsxs)(r.Fragment,{children:[r.jsx(p.Z,{className:"h-4 w-4"}),r.jsx("span",{children:"未解锁"})]}):a?(0,r.jsxs)(r.Fragment,{children:[r.jsx(y,{className:"h-4 w-4"}),r.jsx("span",{children:"重做"})]}):(0,r.jsxs)(r.Fragment,{children:[r.jsx(y,{className:"h-4 w-4"}),r.jsx("span",{children:"开始"})]})})})]})},e.id)})})]})})}},3285:(e,s,t)=>{"use strict";t.r(s),t.d(s,{$$typeof:()=>l,__esModule:()=>a,default:()=>i});let r=(0,t(9279).createProxy)(String.raw`C:\Users\wangqiyuan\project\cursor\aicodegame\src\app\(dashboard)\learn\[courseId]\page.tsx`),{__esModule:a,$$typeof:l}=r,i=r.default}};var s=require("../../../../webpack-runtime.js");s.C(e);var t=e=>s(s.s=e),r=s.X(0,[389,213,499,569,150,438,463],()=>t(9001));module.exports=r})();