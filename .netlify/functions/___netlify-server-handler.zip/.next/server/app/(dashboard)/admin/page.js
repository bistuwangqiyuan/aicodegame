(()=>{var e={};e.id=772,e.ids=[772],e.modules={7849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},5403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},4749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},3685:e=>{"use strict";e.exports=require("http")},5687:e=>{"use strict";e.exports=require("https")},5477:e=>{"use strict";e.exports=require("punycode")},2781:e=>{"use strict";e.exports=require("stream")},7310:e=>{"use strict";e.exports=require("url")},9796:e=>{"use strict";e.exports=require("zlib")},3977:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>n.a,__next_app__:()=>u,originalPathname:()=>p,pages:()=>d,routeModule:()=>m,tree:()=>c});var s=r(5539),a=r(5205),i=r(8464),n=r.n(i),l=r(1088),o={};for(let e in l)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(o[e]=()=>l[e]);r.d(t,o);let c=["",{children:["(dashboard)",{children:["admin",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,644)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\admin\\page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(r.bind(r,2749)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\layout.tsx"],"not-found":[()=>Promise.resolve().then(r.t.bind(r,306,23)),"next/dist/client/components/not-found-error"]}]},{layout:[()=>Promise.resolve().then(r.bind(r,1330)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\layout.tsx"],error:[()=>Promise.resolve().then(r.bind(r,6073)),"C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\error.tsx"],"not-found":[()=>Promise.resolve().then(r.t.bind(r,306,23)),"next/dist/client/components/not-found-error"]}],d=["C:\\Users\\wangqiyuan\\project\\cursor\\aicodegame\\src\\app\\(dashboard)\\admin\\page.tsx"],p="/(dashboard)/admin/page",u={require:r,loadChunk:()=>Promise.resolve()},m=new s.AppPageRouteModule({definition:{kind:a.x.APP_PAGE,page:"/(dashboard)/admin/page",pathname:"/admin",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},5861:(e,t,r)=>{Promise.resolve().then(r.bind(r,2533))},6511:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(5360).Z)("Award",[["circle",{cx:"12",cy:"8",r:"6",key:"1vp47v"}],["path",{d:"M15.477 12.89 17 22l-5-3-5 3 1.523-9.11",key:"em7aur"}]])},5933:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(5360).Z)("BookOpen",[["path",{d:"M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z",key:"vv98re"}],["path",{d:"M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z",key:"1cyq3y"}]])},6179:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(5360).Z)("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]])},2195:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(5360).Z)("Code",[["polyline",{points:"16 18 22 12 16 6",key:"z7tu5w"}],["polyline",{points:"8 6 2 12 8 18",key:"1eg1df"}]])},4430:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(5360).Z)("Home",[["path",{d:"m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"y5dka4"}],["polyline",{points:"9 22 9 12 15 12 15 22",key:"e2us08"}]])},5148:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(5360).Z)("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]])},8852:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(5360).Z)("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]])},8801:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(5360).Z)("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},4707:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(5360).Z)("Sparkles",[["path",{d:"m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z",key:"17u4zn"}],["path",{d:"M5 3v4",key:"bklmnn"}],["path",{d:"M19 17v4",key:"iiml17"}],["path",{d:"M3 5h4",key:"nem4j1"}],["path",{d:"M17 19h4",key:"lbex7p"}]])},4177:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(5360).Z)("TrendingUp",[["polyline",{points:"22 7 13.5 15.5 8.5 10.5 2 17",key:"126l90"}],["polyline",{points:"16 7 22 7 22 13",key:"kwv8wd"}]])},760:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(5360).Z)("Trophy",[["path",{d:"M6 9H4.5a2.5 2.5 0 0 1 0-5H6",key:"17hqa7"}],["path",{d:"M18 9h1.5a2.5 2.5 0 0 0 0-5H18",key:"lmptdp"}],["path",{d:"M4 22h16",key:"57wxv0"}],["path",{d:"M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22",key:"1nw9bq"}],["path",{d:"M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22",key:"1np0yb"}],["path",{d:"M18 2H6v7a6 6 0 0 0 12 0V2Z",key:"u46fv3"}]])},2643:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(5360).Z)("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]])},1809:(e,t,r)=>{"use strict";r.d(t,{Z:()=>s});/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,r(5360).Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]])},2533:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>x});var s=r(7639),a=r(2286),i=r(7438),n=r(8321),l=r(9302),o=r(1809),c=r(5933),d=r(6511);/**
 * @license lucide-react v0.323.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let p=(0,r(5360).Z)("AlertTriangle",[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z",key:"c3ski4"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]]);var u=r(4177),m=r(8801),h=r(2034);function x(){let{profile:e,loading:t}=(0,i.a)(),r=(0,n.useRouter)(),[x,y]=(0,a.useState)({totalUsers:0,activeCourses:0,totalProjects:0,pendingReports:0});(0,a.useEffect)(()=>{if(!t&&e){if("admin"!==e.role&&"teacher"!==e.role){r.push("/");return}g()}},[t,e]);let g=async()=>{let e=(0,l.e)(),{count:t}=await e.from("users").select("*",{count:"exact",head:!0}),{count:r}=await e.from("courses").select("*",{count:"exact",head:!0}).eq("is_published",!0),{count:s}=await e.from("projects").select("*",{count:"exact",head:!0}),{count:a}=await e.from("reports").select("*",{count:"exact",head:!0}).eq("status","pending");y({totalUsers:t||0,activeCourses:r||0,totalProjects:s||0,pendingReports:a||0})};if(t||!e)return s.jsx("div",{className:"flex min-h-screen items-center justify-center",children:s.jsx("div",{className:"loading-spinner"})});if("admin"!==e.role&&"teacher"!==e.role)return s.jsx("div",{className:"flex min-h-screen items-center justify-center",children:(0,s.jsxs)("div",{className:"text-center",children:[s.jsx("h1",{className:"mb-2 text-2xl font-bold text-gray-900",children:"权限不足"}),s.jsx("p",{className:"text-gray-600",children:"你没有访问管理后台的权限"})]})});let v=[{title:"总用户数",value:x.totalUsers,icon:o.Z,color:"from-blue-400 to-blue-600",link:"/admin/users"},{title:"活跃课程",value:x.activeCourses,icon:c.Z,color:"from-purple-400 to-purple-600",link:"/admin/courses"},{title:"作品总数",value:x.totalProjects,icon:d.Z,color:"from-green-400 to-green-600",link:"/admin/projects"},{title:"待处理举报",value:x.pendingReports,icon:p,color:"from-red-400 to-red-600",link:"/admin/reports"}],k=[{title:"用户管理",description:"查看和管理用户账号",icon:o.Z,link:"/admin/users",color:"blue"},{title:"课程管理",description:"创建和编辑课程内容",icon:c.Z,link:"/admin/courses",color:"purple"},{title:"作品审核",description:"审核和管理用户作品",icon:d.Z,link:"/admin/projects",color:"green"},{title:"举报处理",description:"处理用户举报和投诉",icon:p,link:"/admin/reports",color:"red"},{title:"数据统计",description:"查看平台数据和分析",icon:u.Z,link:"/admin/analytics",color:"orange"},{title:"系统设置",description:"配置平台参数和功能",icon:m.Z,link:"/admin/settings",color:"gray"}];return s.jsx("div",{className:"min-h-screen bg-gradient-to-br from-gray-50 via-white to-blue-50 p-6",children:(0,s.jsxs)("div",{className:"mx-auto max-w-7xl",children:[(0,s.jsxs)("div",{className:"mb-8",children:[s.jsx("h1",{className:"mb-2 text-3xl font-bold text-gray-900",children:"管理后台"}),(0,s.jsxs)("p",{className:"text-gray-600",children:["欢迎回来, ",e.display_name||e.username,"!"]})]}),s.jsx("div",{className:"mb-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4",children:v.map((e,t)=>{let r=e.icon;return s.jsx(h.default,{href:e.link,children:(0,s.jsxs)("div",{className:"group cursor-pointer overflow-hidden rounded-2xl border bg-white p-6 shadow-sm transition-all hover:shadow-lg",children:[(0,s.jsxs)("div",{className:"mb-4 flex items-center justify-between",children:[s.jsx("div",{className:`flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${e.color} text-white shadow-lg`,children:s.jsx(r,{className:"h-6 w-6"})}),s.jsx("div",{className:"text-3xl font-bold text-gray-900",children:e.value})]}),s.jsx("h3",{className:"text-sm font-medium text-gray-600",children:e.title})]})},t)})}),(0,s.jsxs)("div",{children:[s.jsx("h2",{className:"mb-4 text-xl font-semibold text-gray-900",children:"快捷操作"}),s.jsx("div",{className:"grid gap-4 sm:grid-cols-2 lg:grid-cols-3",children:k.map((e,t)=>{let r=e.icon;return s.jsx(h.default,{href:e.link,children:(0,s.jsxs)("div",{className:"group cursor-pointer rounded-xl border bg-white p-6 shadow-sm transition-all hover:shadow-md",children:[(0,s.jsxs)("div",{className:"mb-3 flex items-center gap-3",children:[s.jsx("div",{className:`flex h-10 w-10 items-center justify-center rounded-lg bg-${e.color}-100 text-${e.color}-600`,children:s.jsx(r,{className:"h-5 w-5"})}),s.jsx("h3",{className:"font-semibold text-gray-900",children:e.title})]}),s.jsx("p",{className:"text-sm text-gray-600",children:e.description})]})},t)})})]})]})})}},644:(e,t,r)=>{"use strict";r.r(t),r.d(t,{$$typeof:()=>i,__esModule:()=>a,default:()=>n});let s=(0,r(9279).createProxy)(String.raw`C:\Users\wangqiyuan\project\cursor\aicodegame\src\app\(dashboard)\admin\page.tsx`),{__esModule:a,$$typeof:i}=s,n=s.default}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[389,213,499,569,150,438,463],()=>r(3977));module.exports=s})();